// var. 53331
public class Lab4 {
  public static void main(String[] args) {
  C a = new C();
  C b = new B();
  B c = new B();
  a.z5();
  b.z27();
  b.z25();
  c.z34();
  a.z12();
  c.z8();
  c.z2();
  a.z18();
  a.z20();
  a.z21();
  a.z30(a);
  c.z30(b);
  c.z30(c);
  }
}
previous : 2
